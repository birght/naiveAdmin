import{_ as m}from"./BasicSetting.vue_vue_type_script_setup_true_lang-Bbg93At9.js";import"./index-DVGgLLEv.js";export{m as default};
