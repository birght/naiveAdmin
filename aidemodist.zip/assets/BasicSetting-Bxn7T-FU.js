import{_ as m}from"./BasicSetting.vue_vue_type_script_setup_true_lang-CMppmcJy.js";import"./index-DVGgLLEv.js";export{m as default};
