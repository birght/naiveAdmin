import{s as e,o as c,c as o}from"./index-DVGgLLEv.js";const n={};function r(t,s){return c(),o("div",null,"监控台")}const _=e(n,[["render",r]]);export{_ as default};
