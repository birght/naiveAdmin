import{_ as m}from"./CreateDrawer.vue_vue_type_script_setup_true_lang-B-5JTbsb.js";import"./index-DVGgLLEv.js";export{m as default};
