import{s as c}from"./index-DVGgLLEv.js";const r={};function e(s,t){return" 项目文档 "}const o=c(r,[["render",e]]);export{o as default};
