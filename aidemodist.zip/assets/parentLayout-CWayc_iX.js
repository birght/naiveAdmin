import{s as o,ak as r,o as t,am as n}from"./index-DVGgLLEv.js";const c={};function a(s,_){const e=r("router-view");return t(),n(e)}const f=o(c,[["render",a]]);export{f as default};
