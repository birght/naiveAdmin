import{b1 as e}from"./index-DVGgLLEv.js";function o(t){return e.request({url:"/table/list",method:"get",params:t})}export{o as g};
